<div
    <?php echo e($attributes
            ->merge($getExtraAttributes(), escape: false)
            ->class([
                'fi-ta-text grid w-full gap-y-1',
                'px-3 py-4' => ! $isInline(),
            ])); ?>

>
    <div class="flex">
        <?php echo $__env->make($getThemeView(), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php /**PATH D:\PHP\aldidsng\vendor\mokhosh\filament-rating\resources\views/wrappers/column.blade.php ENDPATH**/ ?>