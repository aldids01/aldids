
                    @guest
                        <a href="/admin/login" class="gradient-text">
                            Login
                        </a>
                    @endguest
                