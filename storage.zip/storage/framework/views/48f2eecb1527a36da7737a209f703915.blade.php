
            @guest
                <a href="{{ filament()->getLoginUrl() }}" class="text-sm font-semibold text-gray-600 hover:text-purple-600">
                    Login
                </a>
            @endguest
        