
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(filament()->getLoginUrl()); ?>" class="text-sm font-semibold text-gray-600 hover:text-purple-600">
                    Login
                </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php /**PATH D:\PHP\aldidsng\storage\framework\views/48f2eecb1527a36da7737a209f703915.blade.php ENDPATH**/ ?>