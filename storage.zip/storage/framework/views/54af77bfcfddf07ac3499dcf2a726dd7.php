
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->guest()): ?>
                        <a href="/admin/login" class="bg-gradient-to-r from-primary to-secondary px-4 py-2 rounded-lg text-sm font-medium hover:from-secondary hover:to-primary transition-all duration-300">
                            Login
                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php /**PATH D:\PHP\aldidsng\storage\framework\views/84517a50484ec757c24bcaed4d0fe572.blade.php ENDPATH**/ ?>