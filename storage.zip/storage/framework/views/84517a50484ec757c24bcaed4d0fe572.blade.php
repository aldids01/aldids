
                    @guest
                        <a href="/admin/login" class="bg-gradient-to-r from-primary to-secondary px-4 py-2 rounded-lg text-sm font-medium hover:from-secondary hover:to-primary transition-all duration-300">
                            Login
                        </a>
                    @endguest
                