
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(filament()->getLoginUrl()); ?>" class="fi-topbar-item-btn">
                            Login
                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php /**PATH D:\PHP\aldidsng\storage\framework\views/78ed2ae64f5cb818781369246232dfa9.blade.php ENDPATH**/ ?>