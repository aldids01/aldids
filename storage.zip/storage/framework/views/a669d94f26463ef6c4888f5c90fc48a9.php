<footer class="mt-auto w-full border-t border-white pt-8 pb-4 text-center">
    <p class="text-gray-400 text-sm">
        © <?php echo e(date('Y')); ?> <a href="/" class="hover:text-purple-400 transition">Alpha Digital Developers</a>.
    </p>
</footer>
<?php /**PATH D:\PHP\aldidsng\resources\views/admin-footer.blade.php ENDPATH**/ ?>