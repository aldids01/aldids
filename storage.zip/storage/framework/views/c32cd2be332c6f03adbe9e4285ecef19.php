
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->guest()): ?>
                        <a href="/admin/login" class="fi-topbar-item-btn gradient-text">
                            Login
                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php /**PATH D:\PHP\aldidsng\storage\framework\views/bd5899d22dc4f7a2977e5040ac39eea0.blade.php ENDPATH**/ ?>