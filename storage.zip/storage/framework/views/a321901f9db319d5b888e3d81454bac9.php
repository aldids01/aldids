<?php
    $currentValue = $getState();
    $maxValue = $getMaxValue();
    $status = $getProgressStatus();
    $percentage = $getProgressPercentage();
    $label = $getProgressLabel();
    $color = $getProgressColor();

    if (is_array($color)) {
        $color = $color[0] ?? 'primary';
    }

    // Convert rgb() to rgba() with 15% opacity for light background
    $lightBackgroundColor = str_replace('rgb(', 'rgba(', rtrim($color, ')') . ', 0.15)');
?>

<div
    <?php echo e($attributes
            ->merge($getExtraAttributes(), escape: false)
            ->class(['fi-ta-text block w-full px-3'])); ?>

>
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['flex flex-col gap-1.5 w-full']); ?>">
        <div
            class="<?php echo \Illuminate\Support\Arr::toCssClasses(['relative w-full rounded-full overflow-hidden']); ?>"
            style="height: 0.625rem; background-color: <?php echo e($lightBackgroundColor); ?>;"
            role="progressbar"
            aria-valuenow="<?php echo e($currentValue); ?>"
            aria-valuemin="0"
            aria-valuemax="<?php echo e($maxValue ?? 100); ?>"
            aria-label="<?php echo e($label); ?>"
        >
            <div
                class="<?php echo \Illuminate\Support\Arr::toCssClasses(['h-full rounded-full transition-all duration-300 ease-in-out']); ?>"
                style="width: <?php echo e($percentage); ?>%; background-color: <?php echo e($color); ?>;"
            ></div>
        </div>
        <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-xs text-gray-500 dark:text-gray-400']); ?>">
            <?php echo e($label); ?>

        </span>
    </div>
</div>
<?php /**PATH D:\PHP\aldidsng\vendor\tapp\filament-progress-bar-column\resources\views/columns/progress-bar-column.blade.php ENDPATH**/ ?>